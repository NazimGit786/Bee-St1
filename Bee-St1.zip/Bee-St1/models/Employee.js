const mongoose = require('mongoose')
const Schema = mongoose.Schema

const employeeSchema = new Schema ({
    title: {
        type: String
    },
    content: {
        type: String
    },
    author: {
        type: String
    },
    tags: {
        type: String
    },
    comment: {
        type: String
    }
}, {timestamps: true})

const Employee = mongoose.model('Employee', employeeSchema)
module.exports = Employee